﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a data set entry with a name and value, used in credit summaries.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class DataSet
    {
        /// <summary>
        /// Gets or sets the name of the data set entry.
        /// </summary>
        /// <value>
        /// The name of the data set entry.
        /// </value>
        [Description("The name of the data set entry.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the value of the data set entry.
        /// </summary>
        /// <value>
        /// The value of the data set entry.
        /// </value>
        [Description("The value of the data set entry.")]
        [JsonProperty("@_Value")]
        public string? Value { get; set; }
    }
}