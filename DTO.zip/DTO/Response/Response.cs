﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a response containing keys, status, and response data.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Response
    {
        /// <summary>
        /// Gets or sets the list of key-value pairs in the response.
        /// </summary>
        /// <value>
        /// The list of keys.
        /// </value>
        [Description("The list of key-value pairs in the response.")]
        [JsonProperty("KEY")]
        public List<Key>? Key { get; set; }

        /// <summary>
        /// Gets or sets the Response Date Time of the response.
        /// </summary>
        /// <value>
        /// The Response Date Time.
        /// </value>
        [JsonProperty("@ResponseDateTime")]
        [Description("The ResponseDateTime of the response.")]
        public string? ResponseDateTime { get; set; }

        /// <summary>
        /// Gets or sets the Internal Account Identifier of the response.
        /// </summary>
        /// <value>
        /// The Internal Account Identifier.
        /// </value>
        [JsonProperty("@InternalAccountIdentifier")]
        [Description("The Internal Account Identifier of the response.")]
        public string? InternalAccountIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the status of the response.
        /// </summary>
        /// <value>
        /// The response status.
        /// </value>
        [Description("The status of the response.")]
        [JsonProperty("STATUS")]
        public required Status Status { get; set; }

        /// <summary>
        /// Gets or sets the response data containing detailed information.
        /// </summary>
        /// <value>
        /// The response data.
        /// </value>
        [Description("The response data containing detailed information.")]
        [JsonProperty("RESPONSE_DATA")]
        public ResponseData? ResponseData { get; set; }
    }
}

