﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents an owning bureau, including its identifier, name, address, and contact details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class OwningBureau
    {
        /// <summary>
        /// Gets or sets the unique identifier for the owning bureau.
        /// </summary>
        /// <value>
        /// The identifier of the owning bureau.
        /// </value>
        [Description("The unique identifier for the owning bureau.")]
        [JsonProperty("@_Identifier")]
        public string? Identifier { get; set; }

        /// <summary>
        /// Gets or sets the name of the owning bureau.
        /// </summary>
        /// <value>
        /// The name of the owning bureau.
        /// </value>
        [Description("The name of the owning bureau.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the owning bureau.
        /// </summary>
        /// <value>
        /// The street address of the owning bureau.
        /// </value>
        [Description("The street address of the owning bureau.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the second line of the street address.
        /// </summary>
        /// <value>
        /// The second line of the street address.
        /// </value>
        [Description("The second line of the street address.")]
        [JsonProperty("@_StreetAddress2")]
        public string? StreetAddress2 { get; set; }

        /// <summary>
        /// Gets or sets the city where the owning bureau is located.
        /// </summary>
        /// <value>
        /// The city of the owning bureau.
        /// </value>
        [Description("The city where the owning bureau is located.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state where the owning bureau is located.
        /// </summary>
        /// <value>
        /// The state of the owning bureau.
        /// </value>
        [Description("The state where the owning bureau is located.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the owning bureau.
        /// </summary>
        /// <value>
        /// The postal code of the owning bureau.
        /// </value>
        [Description("The postal code of the owning bureau.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the contact details for the owning bureau.
        /// </summary>
        /// <value>
        /// The contact details for the owning bureau.
        /// </value>
        [Description("The contact details for the owning bureau.")]
        [JsonProperty("CONTACT_DETAIL")]
        public ContactDetail? ContactDetail { get; set; }
    }
}
