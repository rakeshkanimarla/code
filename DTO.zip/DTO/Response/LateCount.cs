﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents late payment counts, including periodic late counts and counts for specific day ranges.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class LateCount
    {
        /// <summary>
        /// Gets or sets the list of periodic late counts.
        /// </summary>
        /// <value>
        /// The list of periodic late counts.
        /// </value>
        [Description("The list of periodic late counts.")]
        [JsonProperty("PERIODIC_LATE_COUNT")]
        [JsonConverter(typeof(SingleOrArrayConverter<PeriodicLateCount>))]
        public List<PeriodicLateCount>? PeriodicLateCount { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 30 days.
        /// </summary>
        /// <value>
        /// The 30-day late payment count.
        /// </value>
        [Description("The count of late payments for 30 days.")]
        [JsonProperty("@_30Days")]
        public string? Days30 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 60 days.
        /// </summary>
        /// <value>
        /// The 60-day late payment count.
        /// </value>
        [Description("The count of late payments for 60 days.")]
        [JsonProperty("@_60Days")]
        public string? Days60 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 90 days.
        /// </summary>
        /// <value>
        /// The 90-day late payment count.
        /// </value>
        [Description("The count of late payments for 90 days.")]
        [JsonProperty("@_90Days")]
        public string? Days90 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 120 days.
        /// </summary>
        /// <value>
        /// The 120-day late payment count.
        /// </value>
        [Description("The count of late payments for 120 days.")]
        [JsonProperty("@_120Days")]
        public string? Days120 { get; set; }
    }
}