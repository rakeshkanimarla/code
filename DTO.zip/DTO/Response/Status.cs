﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the status of a response, including its name, condition, code, and description.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Status
    {
        /// <summary>
        /// Gets or sets the name of the status.
        /// </summary>
        /// <value>
        /// The status name.
        /// </value>
        [Description("The name of the status.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the condition of the status.
        /// </summary>
        /// <value>
        /// The status condition.
        /// </value>
        [Description("The condition of the status.")]
        [JsonProperty("@_Condition")]
        public string? Condition { get; set; }

        /// <summary>
        /// Gets or sets the code of the status.
        /// </summary>
        /// <value>
        /// The status code.
        /// </value>
        [Description("The code of the status.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the description of the status.
        /// </summary>
        /// <value>
        /// The status description.
        /// </value>
        [Description("The description of the status.")]
        [JsonProperty("@_Description")]
        public string? Description { get; set; }
    }
}


