﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a group of response information for a credit response, including the main response, responding party, and respond-to party details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ResponseGroup
    {
        /// <summary>
        /// Gets or sets the response details for the credit response.
        /// </summary>
        /// <value>
        /// The response containing keys, status, and response data.
        /// </value>
        [Description("The response containing keys, status, and response data.")]
        [JsonProperty("RESPONSE")]
        public required Response Response { get; set; }

        /// <summary>
        /// Gets or sets the details of the responding party.
        /// </summary>
        /// <value>
        /// The responding party details.
        /// </value>
        [Description("The details of the responding party.")]
        [JsonProperty("RESPONDING_PARTY")]
        public RespondingParty? RespondingParty { get; set; }

        /// <summary>
        /// Gets or sets the details of the party to whom the response is directed.
        /// </summary>
        /// <value>
        /// The respond-to party details.
        /// </value>
        [Description("The details of the party to whom the response is directed.")]
        [JsonProperty("RESPOND_TO_PARTY")]
        public RespondToParty? RespondToParty { get; set; }
    }
}