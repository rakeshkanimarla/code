﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit score with details about the report, repository, and contributing factors.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditScore
    {
        /// <summary>
        /// Gets or sets the unique identifier for the credit score.
        /// </summary>
        /// <value>
        /// The credit score ID.
        /// </value>
        [Description("The unique identifier for the credit score.")]
        [JsonProperty("@CreditScoreID")]
        public string? CreditScoreID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the borrower associated with this credit score.
        /// </summary>
        /// <value>
        /// The borrower ID.
        /// </value>
        [Description("The identifier for the borrower associated with this credit score.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the credit file associated with this credit score.
        /// </summary>
        /// <value>
        /// The credit file ID.
        /// </value>
        [Description("The identifier for the credit file associated with this credit score.")]
        [JsonProperty("@CreditFileID")]
        public string? CreditFileID { get; set; }

        /// <summary>
        /// Gets or sets the credit report identifier.
        /// </summary>
        /// <value>
        /// The credit report identifier.
        /// </value>
        [Description("The credit report identifier.")]
        [JsonProperty("@CreditReportIdentifier")]
        public string? CreditReportIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit repository source.
        /// </summary>
        /// <value>
        /// The credit repository source type.
        /// </value>
        [Description("The type of the credit repository source.")]
        [JsonProperty("@CreditRepositorySourceType")]
        public string? CreditRepositorySourceType { get; set; }

        /// <summary>
        /// Gets or sets the date the credit score was generated.
        /// </summary>
        /// <value>
        /// The date the credit score was generated.
        /// </value>
        [Description("The date the credit score was generated.")]
        [JsonProperty("@_Date")]
        public string? Date { get; set; }

        /// <summary>
        /// Gets or sets the model name type used for the credit score.
        /// </summary>
        /// <value>
        /// The model name type.
        /// </value>
        [Description("The model name type used for the credit score.")]
        [JsonProperty("@_ModelNameType")]
        public string? ModelNameType { get; set; }

        /// <summary>
        /// Gets or sets the value of the credit score.
        /// </summary>
        /// <value>
        /// The credit score value.
        /// </value>
        [Description("The value of the credit score.")]
        [JsonProperty("@_Value")]
        public string? Value { get; set; }

        /// <summary>
        /// Gets or sets the FACTAInquiriesIndicator of the credit score.
        /// </summary>
        /// <value>
        /// The FACTAInquiriesIndicator value.
        /// </value>
        [Description("FACTAInquiriesIndicator of the credit score.")]
        [JsonProperty("@_FACTAInquiriesIndicator")]
        public string? FACTAInquiriesIndicator { get; set; }

        /// <summary>
        /// Gets or sets the description for other credit repository source types.
        /// </summary>
        /// <value>
        /// The description for other credit repository source types.
        /// </value>
        [Description("The description for other credit repository source types.")]
        [JsonProperty("@CreditRepositorySourceTypeOtherDescription")]
        public string? CreditRepositorySourceTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the description for other model name types.
        /// </summary>
        /// <value>
        /// The description for other model name types.
        /// </value>
        [Description("The description for other model name types.")]
        [JsonProperty("@_ModelNameTypeOtherDescription")]
        public string? ModelNameTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the list of factors contributing to the credit score.
        /// </summary>
        /// <value>
        /// The list of contributing factors.
        /// </value>
        [Description("The list of factors contributing to the credit score.")]
        [JsonProperty("_FACTOR")]
        [JsonConverter(typeof(SingleOrArrayConverter<Factor>))]
        public List<Factor>? Factor { get; set; }
    }
}