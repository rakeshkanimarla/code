﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents contact details, including a name and a collection of contact points.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ContactDetail
    {
        /// <summary>
        /// Gets or sets the name associated with the contact detail.
        /// </summary>
        /// <value>
        /// The name of the contact.
        /// </value>
        [Description("The name associated with the contact detail.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the list of contact points for the contact.
        /// </summary>
        /// <value>
        /// The list of contact points (e.g., phone, email).
        /// </value>
        [Description("The list of contact points for the contact (e.g., phone, email).")]
        [JsonProperty("CONTACT_POINT")]
        [JsonConverter(typeof(SingleOrArrayConverter<ContactPoint>))]
        public List<ContactPoint>? ContactPoint { get; set; }
    }
}