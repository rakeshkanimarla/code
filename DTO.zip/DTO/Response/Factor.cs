﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a factor contributing to a credit score, including a code and description.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Factor
    {
        /// <summary>
        /// Gets or sets the code representing the factor.
        /// </summary>
        /// <value>
        /// The factor code.
        /// </value>
        [Description("The code representing the factor.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the description of the factor.
        /// </summary>
        /// <value>
        /// The factor description.
        /// </value>
        [Description("The description of the factor.")]
        [JsonProperty("@_Text")]
        public string? Text { get; set; }
    }
}

