﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit response containing details about the borrower, liabilities, scores, files, and related credit report information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditResponse
    {
        /// <summary>
        /// Gets or sets the MISMO version ID.
        /// </summary>
        /// <value>
        /// The MISMO version ID.
        /// </value>
        [Description("The MISMO version ID.")]
        [JsonProperty("@MISMOVersionID")]
        public string? MISMOVersionID { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier for the credit response.
        /// </summary>
        /// <value>
        /// The credit response ID.
        /// </value>
        [Description("The unique identifier for the credit response.")]
        [JsonProperty("@CreditResponseID")]
        public string? CreditResponseID { get; set; }

        /// <summary>
        /// Gets or sets the credit report identifier.
        /// </summary>
        /// <value>
        /// The credit report identifier.
        /// </value>
        [Description("The credit report identifier.")]
        [JsonProperty("@CreditReportIdentifier")]
        public string? CreditReportIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the credit report transaction identifier.
        /// </summary>
        /// <value>
        /// The credit report transaction identifier.
        /// </value>
        [Description("The credit report transaction identifier.")]
        [JsonProperty("@CreditReportTransactionIdentifier")]
        public string? CreditReportTransactionIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the date the credit report was first issued.
        /// </summary>
        /// <value>
        /// The credit report first issued date.
        /// </value>
        [Description("The date the credit report was first issued.")]
        [JsonProperty("@CreditReportFirstIssuedDate")]
        public string? CreditReportFirstIssuedDate { get; set; }

        /// <summary>
        /// Gets or sets the date the credit report was last updated.
        /// </summary>
        /// <value>
        /// The credit report last updated date.
        /// </value>
        [Description("The date the credit report was last updated.")]
        [JsonProperty("@CreditReportLastUpdatedDate")]
        public string? CreditReportLastUpdatedDate { get; set; }

        /// <summary>
        /// Gets or sets the merge type of the credit report.
        /// </summary>
        /// <value>
        /// The credit report merge type.
        /// </value>
        [Description("The merge type of the credit report.")]
        [JsonProperty("@CreditReportMergeType")]
        public string? CreditReportMergeType { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit report.
        /// </summary>
        /// <value>
        /// The credit report type.
        /// </value>
        [Description("The type of the credit report.")]
        [JsonProperty("@CreditReportType")]
        public string? CreditReportType { get; set; }

        /// <summary>
        /// Gets or sets the credit rating code type.
        /// </summary>
        /// <value>
        /// The credit rating code type.
        /// </value>
        [Description("The credit rating code type.")]
        [JsonProperty("@CreditRatingCodeType")]
        public string? CreditRatingCodeType { get; set; }

        /// <summary>
        /// Gets or sets the credit bureau information.
        /// </summary>
        /// <value>
        /// The credit bureau.
        /// </value>
        [Description("The credit bureau information.")]
        [JsonProperty("CREDIT_BUREAU")]
        public CreditBureau? CreditBureau { get; set; }

        /// <summary>
        /// Gets or sets the list of credit report prices.
        /// </summary>
        /// <value>
        /// The list of credit report prices.
        /// </value>
        [Description("The list of credit report prices.")]
        [JsonProperty("CREDIT_REPORT_PRICE")]
        public List<CreditReportPrice>? CreditReportPrice { get; set; }

        /// <summary>
        /// Gets or sets the included credit repository information.
        /// </summary>
        /// <value>
        /// The included credit repository information.
        /// </value>
        [Description("The included credit repository information.")]
        [JsonProperty("CREDIT_REPOSITORY_INCLUDED")]
        public CreditRepositoryIncluded? CreditRepositoryIncluded { get; set; }

        /// <summary>
        /// Gets or sets the requesting party information.
        /// </summary>
        /// <value>
        /// The requesting party.
        /// </value>
        [Description("The requesting party information.")]
        [JsonProperty("REQUESTING_PARTY")]
        public RequestingParty? RequestingParty { get; set; }

        /// <summary>
        /// Gets or sets the credit request data.
        /// </summary>
        /// <value>
        /// The credit request data.
        /// </value>
        [Description("The credit request data.")]
        [JsonProperty("CREDIT_REQUEST_DATA")]
        public CreditRequestData? CreditRequestData { get; set; }

        /// <summary>
        /// Gets or sets the list of borrowers associated with the credit response.
        /// </summary>
        /// <value>
        /// The list of borrowers.
        /// </value>
        [Description("The list of borrowers associated with the credit response.")]
        [JsonProperty("BORROWER")]
        [JsonConverter(typeof(SingleOrArrayConverter<Borrower>))]
        public required List<Borrower> Borrower { get; set; }

        /// <summary>
        /// Gets or sets the list of credit liabilities.
        /// </summary>
        /// <value>
        /// The list of credit liabilities.
        /// </value>
        [Description("The list of credit liabilities.")]
        [JsonProperty("CREDIT_LIABILITY")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditLiability>))]
        public List<CreditLiability>? CreditLiability { get; set; }

        /// <summary>
        /// Gets or sets the list of credit files.
        /// </summary>
        /// <value>
        /// The list of credit files.
        /// </value>
        [Description("The list of credit files.")]
        [JsonProperty("CREDIT_FILE")]
        public List<CreditFile>? CreditFile { get; set; }

        /// <summary>
        /// Gets or sets the list of Credit Public Records..
        /// </summary>
        /// <value>
        /// The list of Credit Public Records..
        /// </value>
        [Description("The list of Credit Public Records.")]
        [JsonProperty("CREDIT_PUBLIC_RECORD")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditPublicRecord>))]
        public List<CreditPublicRecord>? CreditPublicRecord { get; set; }

        /// <summary>
        /// Gets or sets the list of credit scores.
        /// </summary>
        /// <value>
        /// The list of credit scores.
        /// </value>
        [Description("The list of credit scores.")]
        [JsonProperty("CREDIT_SCORE")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditScore>))]
        public List<CreditScore>? CreditScore { get; set; }

        /// <summary>
        /// Gets or sets the list of credit comments.
        /// </summary>
        /// <value>
        /// The list of credit comments.
        /// </value>
        [Description("The list of credit comments.")]
        [JsonProperty("CREDIT_COMMENT")]
        public List<CreditComment>? CreditComment { get; set; }

        /// <summary>
        /// Gets or sets the list of consumer referrals.
        /// </summary>
        /// <value>
        /// The list of consumer referrals.
        /// </value>
        [Description("The list of consumer referrals.")]
        [JsonProperty("CREDIT_CONSUMER_REFERRAL")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditConsumerReferral>))]
        public List<CreditConsumerReferral>? CreditConsumerReferral { get; set; }

        /// <summary>
        /// Gets or sets the credit summary information.
        /// </summary>
        /// <value>
        /// The credit summary.
        /// </value>
        [Description("The credit summary information.")]
        [JsonProperty("CREDIT_SUMMARY")]
        public CreditSummary? CreditSummary { get; set; }

        /// <summary>
        /// Gets or sets the regulatory product information.
        /// </summary>
        /// <value>
        /// The regulatory product.
        /// </value>
        [Description("The regulatory product information.")]
        [JsonProperty("REGULATORY_PRODUCT")]
        [JsonConverter(typeof(SingleOrArrayConverter<RegulatoryProduct>))]
        public List<RegulatoryProduct>? RegulatoryProduct { get; set; }

        /// <summary>
        /// Gets or sets the embedded file information.
        /// </summary>
        /// <value>
        /// The embedded file.
        /// </value>
        [Description("The embedded file information.")]
        [JsonProperty("EMBEDDED_FILE")]
        public EmbeddedFile? EmbeddedFile { get; set; }

        /// <summary>
        /// Gets or sets the credit error message.
        /// </summary>
        /// <value>
        /// The credit error message.
        /// </value>
        [Description("The credit error message.")]
        [JsonProperty("CREDIT_ERROR_MESSAGE")]
        public CreditErrorMessage? CreditErrorMessage { get; set; }
    }
}
