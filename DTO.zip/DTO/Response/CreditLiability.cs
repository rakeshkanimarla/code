﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit liability with details about the account, loan, and creditor.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditLiability
    {
        /// <summary>
        /// Gets or sets the unique identifier for the credit liability.
        /// </summary>
        /// <value>
        /// The credit liability ID.
        /// </value>
        [Description("The unique identifier for the credit liability.")]
        [JsonProperty("@CreditLiabilityID")]
        public string? CreditLiabilityID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the borrower associated with this liability.
        /// </summary>
        /// <value>
        /// The borrower ID.
        /// </value>
        [Description("The identifier for the borrower associated with this liability.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the credit file associated with this liability.
        /// </summary>
        /// <value>
        /// The credit file ID.
        /// </value>
        [Description("The identifier for the credit file associated with this liability.")]
        [JsonProperty("@CreditFileID")]
        public string? CreditFileID { get; set; }

        /// <summary>
        /// Gets or sets the account identifier for the liability.
        /// </summary>
        /// <value>
        /// The account identifier.
        /// </value>
        [Description("The account identifier for the liability.")]
        [JsonProperty("@_AccountIdentifier")]
        public string? AccountIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the date the account was opened.
        /// </summary>
        /// <value>
        /// The account opened date.
        /// </value>
        [Description("The date the account was opened.")]
        [JsonProperty("@_AccountOpenedDate")]
        public string? AccountOpenedDate { get; set; }

        /// <summary>
        /// Gets or sets the ownership type of the account.
        /// </summary>
        /// <value>
        /// The account ownership type.
        /// </value>
        [Description("The ownership type of the account.")]
        [JsonProperty("@_AccountOwnershipType")]
        public string? AccountOwnershipType { get; set; }

        /// <summary>
        /// Gets or sets the date the account was last reported.
        /// </summary>
        /// <value>
        /// The account reported date.
        /// </value>
        [Description("The date the account was last reported.")]
        [JsonProperty("@_AccountReportedDate")]
        public string? AccountReportedDate { get; set; }

        /// <summary>
        /// Gets or sets the status type of the account.
        /// </summary>
        /// <value>
        /// The account status type.
        /// </value>
        [Description("The status type of the account.")]
        [JsonProperty("@_AccountStatusType")]
        public string? AccountStatusType { get; set; }

        /// <summary>
        /// Gets or sets the type of the account.
        /// </summary>
        /// <value>
        /// The account type.
        /// </value>
        [Description("The type of the account.")]
        [JsonProperty("@_AccountType")]
        public string? AccountType { get; set; }

        /// <summary>
        /// Gets or sets the credit limit amount for the account.
        /// </summary>
        /// <value>
        /// The credit limit amount.
        /// </value>
        [Description("The credit limit amount for the account.")]
        [JsonProperty("@_CreditLimitAmount")]
        public string? CreditLimitAmount { get; set; }

        /// <summary>
        /// Gets or sets the highest credit amount for the account.
        /// </summary>
        /// <value>
        /// The high credit amount.
        /// </value>
        [Description("The highest credit amount for the account.")]
        [JsonProperty("@_HighCreditAmount")]
        public string? HighCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets the date of the last activity on the account.
        /// </summary>
        /// <value>
        /// The last activity date.
        /// </value>
        [Description("The date of the last activity on the account.")]
        [JsonProperty("@_LastActivityDate")]
        public string? LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets the monthly payment amount for the account.
        /// </summary>
        /// <value>
        /// The monthly payment amount.
        /// </value>
        [Description("The monthly payment amount for the account.")]
        [JsonProperty("@_MonthlyPaymentAmount")]
        public string? MonthlyPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets the number of months remaining on the account.
        /// </summary>
        /// <value>
        /// The months remaining count.
        /// </value>
        [Description("The number of months remaining on the account.")]
        [JsonProperty("@_MonthsRemainingCount")]
        public string? MonthsRemainingCount { get; set; }

        /// <summary>
        /// Gets or sets the number of months reviewed for the account.
        /// </summary>
        /// <value>
        /// The months reviewed count.
        /// </value>
        [Description("The number of months reviewed for the account.")]
        [JsonProperty("@_MonthsReviewedCount")]
        public string? _MonthsReviewedCount { get; set; }

        /// <summary>
        /// Gets or sets the unpaid balance amount for the account.
        /// </summary>
        /// <value>
        /// The unpaid balance amount.
        /// </value>
        [Description("The unpaid balance amount for the account.")]
        [JsonProperty("@_UnpaidBalanceAmount")]
        public string? UnpaidBalanceAmount { get; set; }

        /// <summary>
        /// Gets or sets the Past Due Amount for the account.
        /// </summary>
        /// <value>
        /// The Past Due Amount.
        /// </value>
        [Description("The Past Due Amount for the account.")]
        [JsonProperty("@_PastDueAmount")]
        public string? PastDueAmount { get; set; }

        /// <summary>
        /// Gets or sets the business type for the credit.
        /// </summary>
        /// <value>
        /// The credit business type.
        /// </value>
        [Description("The business type for the credit.")]
        [JsonProperty("@CreditBusinessType")]
        public string? CreditBusinessType { get; set; }

        /// <summary>
        /// Gets or sets the loan type for the credit.
        /// </summary>
        /// <value>
        /// The credit loan type.
        /// </value>
        [Description("The loan type for the credit.")]
        [JsonProperty("@CreditLoanType")]
        public string? CreditLoanType { get; set; }

        /// <summary>
        /// Gets or sets the source type for the terms of the account.
        /// </summary>
        /// <value>
        /// The terms source type.
        /// </value>
        [Description("The source type for the terms of the account.")]
        [JsonProperty("@_TermsSourceType")]
        public string? TermsSourceType { get; set; }

        /// <summary>
        /// Gets or sets the number of months for the account terms.
        /// </summary>
        /// <value>
        /// The terms months count.
        /// </value>
        [Description("The number of months for the account terms.")]
        [JsonProperty("@_TermsMonthsCount")]
        public string? TermsMonthsCount { get; set; }

        /// <summary>
        /// Gets or sets the description of the account terms.
        /// </summary>
        /// <value>
        /// The terms description.
        /// </value>
        [Description("The description of the account terms.")]
        [JsonProperty("@_TermsDescription")]
        public string? TermsDescription { get; set; }

        /// <summary>
        /// Gets or sets the creditor associated with the credit liability.
        /// </summary>
        /// <value>
        /// The creditor.
        /// </value>
        [Description("The creditor associated with the credit liability.")]
        [JsonProperty("_CREDITOR")]
        public Creditor? Creditor { get; set; }

        /// <summary>
        /// Gets or sets the current rating for the account.
        /// </summary>
        /// <value>
        /// The current rating.
        /// </value>
        [Description("The current rating for the account.")]
        [JsonProperty("_CURRENT_RATING")]
        public CurrentRating? CurrentRating { get; set; }

        /// <summary>
        /// Gets or sets the late count information for the account.
        /// </summary>
        /// <value>
        /// The late count information.
        /// </value>
        [Description("The late count information for the account.")]
        [JsonProperty("_LATE_COUNT")]
        public LateCount? LateCount { get; set; }

        /// <summary>
        /// Gets or sets the payment pattern for the account.
        /// </summary>
        /// <value>
        /// The payment pattern.
        /// </value>
        [Description("The payment pattern for the account.")]
        [JsonProperty("_PAYMENT_PATTERN")]
        public PaymentPattern? PaymentPattern { get; set; }

        /// <summary>
        /// Gets or sets the credit comment associated with the account.
        /// </summary>
        /// <value>
        /// The credit comment.
        /// </value>
        [Description("The credit comment associated with the account.")]
        [JsonProperty("CREDIT_COMMENT")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditComment>))]
        public List<CreditComment>? CreditComment { get; set; }

        /// <summary>
        /// Gets or sets the list of credit repositories associated with the account.
        /// </summary>
        /// <value>
        /// The list of credit repositories.
        /// </value>
        [Description("The list of credit repositories associated with the account.")]
        [JsonProperty("CREDIT_REPOSITORY")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditRepository>))]
        public List<CreditRepository>? CreditRepository { get; set; }

        /// <summary>
        /// Gets or sets the list of Prior Adverse Ratings associated with the account.
        /// </summary>
        /// <value>
        /// The list of Prior Adverse Ratings.
        /// </value>
        [Description("The list of Prior Adverse Ratings associated with the account.")]
        [JsonProperty("_PRIOR_ADVERSE_RATING")]
        [JsonConverter(typeof(SingleOrArrayConverter<PriorAdverseRating>))]
        public List<PriorAdverseRating>? PriorAdverseRating { get; set; }

        /// <summary>
        /// Gets or sets the list of Highest Adverse Ratings associated with the account.
        /// </summary>
        /// <value>
        /// The list of Highest Adverse Ratings.
        /// </value>
        [Description("The list of Highest Adverse Ratings associated with the account.")]
        [JsonProperty("_HIGHEST_ADVERSE_RATING ")]
        [JsonConverter(typeof(SingleOrArrayConverter<HighestAdverseRating>))]
        public List<HighestAdverseRating>? HighestAdverseRating { get; set; }

        /// <summary>
        /// Gets or sets the list of Most Recent Adverse Ratings associated with the account.
        /// </summary>
        /// <value>
        /// The list of Most Recent Adverse Ratings.
        /// </value>
        [Description("The list of Most Recent Adverse Ratings associated with the account.")]
        [JsonProperty("_HIGHEST_ADVERSE_RATING ")]
        [JsonConverter(typeof(SingleOrArrayConverter<MostRecentAdverseRating>))]
        public List<MostRecentAdverseRating>? MostRecentAdverseRating { get; set; }
    }
}