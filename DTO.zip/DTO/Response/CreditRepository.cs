﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit repository, including source type and subscriber code information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditRepository
    {
        /// <summary>
        /// Gets or sets the source type of the credit repository.
        /// </summary>
        /// <value>
        /// The source type of the credit repository.
        /// </value>
        [Description("The source type of the credit repository.")]
        [JsonProperty("@_SourceType")]
        public string? SourceType { get; set; }

        /// <summary>
        /// Gets or sets the description for other source types not covered by standard types.
        /// </summary>
        /// <value>
        /// The description for other source types.
        /// </value>
        [Description("The description for other source types not covered by standard types.")]
        [JsonProperty("@_SourceTypeOtherDescription")]
        public string? SourceTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the subscriber code for the credit repository.
        /// </summary>
        /// <value>
        /// The subscriber code.
        /// </value>
        [Description("The subscriber code for the credit repository.")]
        [JsonProperty("@_SubscriberCode")]
        public string? SubscriberCode { get; set; }
    }
}
