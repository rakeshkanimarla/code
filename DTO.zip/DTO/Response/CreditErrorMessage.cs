﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents an error message related to a credit response, including text, code, and source type.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditErrorMessage
    {
        /// <summary>
        /// Gets or sets the list of error message text entries.
        /// </summary>
        /// <value>
        /// The list of error message text entries.
        /// </value>
        [Description("The list of error message text entries.")]
        [JsonProperty("_Text")]
        [JsonConverter(typeof(SingleOrArrayConverter<string>))]
        public List<string>? Text { get; set; }

        /// <summary>
        /// Gets or sets the code associated with the error message.
        /// </summary>
        /// <value>
        /// The code for the error message.
        /// </value>
        [Description("The code associated with the error message.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the source type of the error message.
        /// </summary>
        /// <value>
        /// The source type of the error message.
        /// </value>
        [Description("The source type of the error message.")]
        [JsonProperty("@_SourceType")]
        public string? SourceType { get; set; }
    }
}