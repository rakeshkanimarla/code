﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the current rating for a credit account, including code and type information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CurrentRating
    {
        /// <summary>
        /// Gets or sets the code representing the current rating.
        /// </summary>
        /// <value>
        /// The current rating code.
        /// </value>
        [Description("The code representing the current rating.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the type of the current rating.
        /// </summary>
        /// <value>
        /// The current rating type.
        /// </value>
        [Description("The type of the current rating.")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }
    }
}
