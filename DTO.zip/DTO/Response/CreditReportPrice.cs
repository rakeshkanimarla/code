﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the price information for a credit report, including amount and type details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditReportPrice
    {
        /// <summary>
        /// Gets or sets the amount charged for the credit report.
        /// </summary>
        /// <value>
        /// The price amount.
        /// </value>
        [Description("The amount charged for the credit report.")]
        [JsonProperty("@_Amount")]
        public string? Amount { get; set; }

        /// <summary>
        /// Gets or sets the type of the price (e.g., base, additional).
        /// </summary>
        /// <value>
        /// The price type.
        /// </value>
        [Description("The type of the price (e.g., base, additional).")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the description for other price types not covered by standard types.
        /// </summary>
        /// <value>
        /// The description for other price types.
        /// </value>
        [Description("The description for other price types not covered by standard types.")]
        [JsonProperty("@_TypeOtherDescription")]
        public string? TypeOtherDescription { get; set; }
    }
}