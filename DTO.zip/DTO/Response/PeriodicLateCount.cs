﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a periodic late count entry, including type and counts for specific day ranges.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PeriodicLateCount
    {
        /// <summary>
        /// Gets or sets the type of the periodic late count.
        /// </summary>
        /// <value>
        /// The type of the periodic late count.
        /// </value>
        [Description("The type of the periodic late count.")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 30 days.
        /// </summary>
        /// <value>
        /// The 30-day late payment count.
        /// </value>
        [Description("The count of late payments for 30 days.")]
        [JsonProperty("@_30Days")]
        public string? Days30 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 60 days.
        /// </summary>
        /// <value>
        /// The 60-day late payment count.
        /// </value>
        [Description("The count of late payments for 60 days.")]
        [JsonProperty("@_60Days")]
        public string? Days60 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 90 days.
        /// </summary>
        /// <value>
        /// The 90-day late payment count.
        /// </value>
        [Description("The count of late payments for 90 days.")]
        [JsonProperty("@_90Days")]
        public string? Days90 { get; set; }

        /// <summary>
        /// Gets or sets the count of late payments for 120 days.
        /// </summary>
        /// <value>
        /// The 120-day late payment count.
        /// </value>
        [Description("The count of late payments for 120 days.")]
        [JsonProperty("@_120Days")]
        public string? Days120 { get; set; }
    }
}