﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents an alert message with a code and text.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AlertMessage
    {
        /// <summary>
        /// Gets or sets the alert code.
        /// </summary>
        /// <value>
        /// The alert code.
        /// </value>
        [Description("The code that identifies the alert.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the alert text.
        /// </summary>
        /// <value>
        /// The alert text.
        /// </value>
        [Description("The descriptive text of the alert message.")]
        [JsonProperty("_Text")]
        [JsonConverter(typeof(SingleOrArrayConverter<string>))]
        public List<string>? Text { get; set; }

        /// <summary>
        /// Gets or sets the category type of the alert.
        /// </summary>
        /// <value>
        /// The category type of the alert.
        /// </value>
        [Description("The category type associated with the alert.")]
        [JsonProperty("@_CategoryType")]
        public string? CategoryType { get; set; }

        /// <summary>
        /// Gets or sets the type of the alert.
        /// </summary>
        /// <value>
        /// The type of the alert.
        /// </value>
        [Description("The type of the alert message.")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the adverse indicator for the alert.
        /// </summary>
        /// <value>
        /// The adverse indicator.
        /// </value>
        [Description("Indicates whether the alert is adverse.")]
        [JsonProperty("@_AdverseIndicator")]
        public string? AdverseIndicator { get; set; }
    }
}
