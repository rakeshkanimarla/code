﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit file containing alert messages, comments, borrower information, and related metadata.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditFile
    {
        /// <summary>
        /// Gets or sets the unique identifier for the credit file.
        /// </summary>
        /// <value>
        /// The credit file ID.
        /// </value>
        [Description("The unique identifier for the credit file.")]
        [JsonProperty("@CreditFileID")]
        public string? CreditFileID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the borrower.
        /// </summary>
        /// <value>
        /// The borrower ID.
        /// </value>
        [Description("The identifier for the borrower.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the credit score.
        /// </summary>
        /// <value>
        /// The credit score ID.
        /// </value>
        [Description("The identifier for the credit score.")]
        [JsonProperty("@CreditScoreID")]
        public string? CreditScoreID { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit repository source.
        /// </summary>
        /// <value>
        /// The credit repository source type.
        /// </value>
        [Description("The type of the credit repository source.")]
        [JsonProperty("@CreditRepositorySourceType")]
        public string? CreditRepositorySourceType { get; set; }

        /// <summary>
        /// Gets or sets the description for other credit repository source types.
        /// </summary>
        /// <value>
        /// The description for other credit repository source types.
        /// </value>
        [Description("The description for other credit repository source types.")]
        [JsonProperty("@CreditRepositorySourceTypeOtherDescription")]
        public string? CreditRepositorySourceTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the infile date for the credit file.
        /// </summary>
        /// <value>
        /// The infile date.
        /// </value>
        [Description("The infile date for the credit file.")]
        [JsonProperty("@_InfileDate")]
        public string? InfileDate { get; set; }

        /// <summary>
        /// Gets or sets the result status type for the credit file.
        /// </summary>
        /// <value>
        /// The result status type.
        /// </value>
        [Description("The result status type for the credit file.")]
        [JsonProperty("@_ResultStatusType")]
        public string? ResultStatusType { get; set; }

        /// <summary>
        /// Gets or sets the description for other result status types.
        /// </summary>
        /// <value>
        /// The description for other result status types.
        /// </value>
        [Description("The description for other result status types.")]
        [JsonProperty("@_ResultStatusTypeOtherDescription")]
        public string? ResultStatusTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the alert message associated with the credit file.
        /// </summary>
        /// <value>
        /// The alert message.
        /// </value>
        [Description("The alert message associated with the credit file.")]
        [JsonProperty("_ALERT_MESSAGE")]
        [JsonConverter(typeof(SingleOrArrayConverter<AlertMessage>))]
        public List<AlertMessage>? AlertMessage { get; set; }

        /// <summary>
        /// Gets or sets the credit comment associated with the credit file.
        /// </summary>
        /// <value>
        /// The credit comment.
        /// </value>
        [Description("The credit comment associated with the credit file.")]
        [JsonProperty("CREDIT_COMMENT")]
        public CreditComment? CreditComment { get; set; }

        /// <summary>
        /// Gets or sets the Owning Bureau associated with the credit file.
        /// </summary>
        /// <value>
        /// The Owning Bureau.
        /// </value>
        [Description("The Owning Bureau associated with the credit file.")]
        [JsonProperty("_OWNING_BUREAU")]
        public OwningBureau? OwningBureau { get; set; }

        /// <summary>
        /// Gets or sets the borrower information associated with the credit file.
        /// </summary>
        /// <value>
        /// The borrower information.
        /// </value>
        [Description("The borrower information associated with the credit file.")]
        [JsonProperty("_BORROWER")]
        public Borrower? Borrower { get; set; }
    }
}