﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a contact point, such as a phone number or email address, with its type and value.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ContactPoint
    {
        /// <summary>
        /// Gets or sets the type of the contact point (e.g., Phone, Email).
        /// </summary>
        /// <value>
        /// The type of the contact point.
        /// </value>
        [Description("The type of the contact point (e.g., Phone, Email).")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the value of the contact point.
        /// </summary>
        /// <value>
        /// The value of the contact point.
        /// </value>
        [Description("The value of the contact point (e.g., the phone number or email address).")]
        [JsonProperty("@_Value")]
        public string? Value { get; set; }
    }
}
