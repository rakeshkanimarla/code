﻿// Copyright © 2024 Wolters Kluwer. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    public class CreditPublicRecord
    {
        [JsonProperty("CREDIT_REPOSITORY")]
        [JsonConverter(typeof(SingleOrArrayConverter<CreditRepository>))]
        public List<CreditRepository>? CreditRepository { get; set; }

        [JsonProperty("@CreditPublicRecordID")]
        public string? CreditPublicRecordID { get; set; }

        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        [JsonProperty("@CreditFileID")]
        public string? CreditFileID { get; set; }

        [JsonProperty("@CreditTradeReferenceID")]
        public string? CreditTradeReferenceID { get; set; }

        [JsonProperty("@_AccountOwnershipType")]
        public string? AccountOwnershipType { get; set; }

        [JsonProperty("@_AttorneyName")]
        public string? AttorneyName { get; set; }

        [JsonProperty("@_BankruptcyAdjustmentPercent")]
        public string? BankruptcyAdjustmentPercent { get; set; }

        [JsonProperty("@_BankruptcyAssetsAmount")]
        public string? BankruptcyAssetsAmount { get; set; }

        [JsonProperty("@_BankruptcyExemptAmount")]
        public string? BankruptcyExemptAmount { get; set; }

        [JsonProperty("@_BankruptcyLiabilitiesAmount")]
        public string? BankruptcyLiabilitiesAmount { get; set; }

        [JsonProperty("@_BankruptcyRepaymentPercent")]
        public string? BankruptcyRepaymentPercent { get; set; }

        [JsonProperty("@_BankruptcyType")]
        public string? BankruptcyType { get; set; }

        [JsonProperty("@_ConsumerDisputeIndicator")]
        public string? ConsumerDisputeIndicator { get; set; }

        [JsonProperty("@_CourtName")]
        public string? CourtName { get; set; }

        [JsonProperty("@_DefendantName")]
        public string? DefendantName { get; set; }

        [JsonProperty("@_DerogatoryDataIndicator")]
        public string? DerogatoryDataIndicator { get; set; }

        [JsonProperty("@_DispositionDate")]
        public string? DispositionDate { get; set; }
        [JsonProperty("@_DispositionType")]
        public string? DispositionType { get; set; }

        [JsonProperty("@_DispositionTypeOtherDescription")]
        public string? DispositionTypeOtherDescription { get; set; }

        [JsonProperty("@_DocketIdentifier")]
        public string? DocketIdentifier { get; set; }

        [JsonProperty("@_FiledDate")]
        public string? FiledDate { get; set; }

        [JsonProperty("@_LegalObligationAmount")]
        public string? LegalObligationAmount { get; set; }

        [JsonProperty("@_ManualUpdateIndicator")]
        public string? ManualUpdateIndicator { get; set; }

        [JsonProperty("@_PaidDate")]
        public string? PaidDate { get; set; }

        [JsonProperty("@_PaymentFrequencyType")]
        public string? _PaymentFrequencyType { get; set; }

        [JsonProperty("@_PlaintiffName")]
        public string? PlaintiffName { get; set; }

        [JsonProperty("@_ReportedDate")]
        public string? ReportedDate { get; set; }

        [JsonProperty("@_SettledDate")]
        public string? SettledDate { get; set; }

        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        [JsonProperty("@_TypeOtherDescription")]
        public string? TypeOtherDescription { get; set; }
    }
}
