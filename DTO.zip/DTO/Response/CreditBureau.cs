﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit bureau, including its name, address, and contact details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditBureau
    {
        /// <summary>
        /// Gets or sets the name of the credit bureau.
        /// </summary>
        /// <value>
        /// The name of the credit bureau.
        /// </value>
        [Description("The name of the credit bureau.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the credit bureau.
        /// </summary>
        /// <value>
        /// The street address of the credit bureau.
        /// </value>
        [Description("The street address of the credit bureau.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city where the credit bureau is located.
        /// </summary>
        /// <value>
        /// The city of the credit bureau.
        /// </value>
        [Description("The city where the credit bureau is located.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state where the credit bureau is located.
        /// </summary>
        /// <value>
        /// The state of the credit bureau.
        /// </value>
        [Description("The state where the credit bureau is located.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the credit bureau.
        /// </summary>
        /// <value>
        /// The postal code of the credit bureau.
        /// </value>
        [Description("The postal code of the credit bureau.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the contact details for the credit bureau.
        /// </summary>
        /// <value>
        /// The contact details for the credit bureau.
        /// </value>
        [Description("The contact details for the credit bureau.")]
        [JsonProperty("CONTACT_DETAIL")]
        public required ContactDetail ContactDetail { get; set; }
    }
}