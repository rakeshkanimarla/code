﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a creditor with a name.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Creditor
    {
        /// <summary>
        /// Gets or sets the name of the creditor.
        /// </summary>
        /// <value>
        /// The creditor's name.
        /// </value>
        [Description("The name of the creditor.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }
    }
}
