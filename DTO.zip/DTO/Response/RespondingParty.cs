﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a responding party, including name, address, identifier, and contact details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RespondingParty
    {
        /// <summary>
        /// Gets or sets the name of the responding party.
        /// </summary>
        /// <value>
        /// The name of the responding party.
        /// </value>
        [Description("The name of the responding party.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the responding party.
        /// </summary>
        /// <value>
        /// The street address of the responding party.
        /// </value>
        [Description("The street address of the responding party.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city where the responding party is located.
        /// </summary>
        /// <value>
        /// The city of the responding party.
        /// </value>
        [Description("The city where the responding party is located.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state where the responding party is located.
        /// </summary>
        /// <value>
        /// The state of the responding party.
        /// </value>
        [Description("The state where the responding party is located.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the responding party.
        /// </summary>
        /// <value>
        /// The postal code of the responding party.
        /// </value>
        [Description("The postal code of the responding party.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the second line of the street address.
        /// </summary>
        /// <value>
        /// The second line of the street address.
        /// </value>
        [Description("The second line of the street address.")]
        [JsonProperty("@_StreetAddress2")]
        public string? StreetAddress2 { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier for the responding party.
        /// </summary>
        /// <value>
        /// The identifier of the responding party.
        /// </value>
        [Description("The unique identifier for the responding party.")]
        [JsonProperty("@_Identifier")]
        public string? Identifier { get; set; }

        /// <summary>
        /// Gets or sets the contact details for the responding party.
        /// </summary>
        /// <value>
        /// The contact details for the responding party.
        /// </value>
        [Description("The contact details for the responding party.")]
        [JsonProperty("CONTACT_DETAIL")]
        public ContactDetail? ContactDetail { get; set; }
    }
}