﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a payment pattern, including pattern data and the start date.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PaymentPattern
    {
        /// <summary>
        /// Gets or sets the payment pattern data.
        /// </summary>
        /// <value>
        /// The payment pattern data.
        /// </value>
        [Description("The payment pattern data.")]
        [JsonProperty("@_Data")]
        public string? Data { get; set; }

        /// <summary>
        /// Gets or sets the start date for the payment pattern.
        /// </summary>
        /// <value>
        /// The start date for the payment pattern.
        /// </value>
        [Description("The start date for the payment pattern.")]
        [JsonProperty("@_StartDate")]
        public string? StartDate { get; set; }
    }
}
