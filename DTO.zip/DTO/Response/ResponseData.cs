﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the data contained in a response, including credit response details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ResponseData
    {
        /// <summary>
        /// Gets or sets the credit response details.
        /// </summary>
        /// <value>
        /// The credit response containing borrower, liabilities, scores, and files.
        /// </value>
        [Description("The credit response containing borrower, liabilities, scores, and files.")]
        [JsonProperty("CREDIT_RESPONSE")]
        public required CreditResponse CreditResponse { get; set; }
    }
}

