﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the model for a credit response, containing the response details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CBCCreditResponseModel
    {
        /// <summary>
        /// Gets or sets the response group containing the credit response details.
        /// </summary>
        /// <value>
        /// The response group with response, responding party, and respond-to party information.
        /// </value>
        [Description("The response group containing the credit response details, including response, responding party, and respond-to party information.")]
        [JsonProperty("RESPONSE_GROUP")]
        public required ResponseGroup ResponseGroup { get; set; }
    }
}
