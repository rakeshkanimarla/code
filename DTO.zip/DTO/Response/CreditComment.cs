﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit comment, including text, code, source type, and additional type information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditComment
    {
        /// <summary>
        /// Gets or sets the list of comment text entries.
        /// </summary>
        /// <value>
        /// The list of comment text entries.
        /// </value>
        [Description("The list of comment text entries.")]
        [JsonProperty("_Text")]
        [JsonConverter(typeof(SingleOrArrayConverter<string>))]
        public List<string>? Text { get; set; }

        /// <summary>
        /// Gets or sets the code associated with the credit comment.
        /// </summary>
        /// <value>
        /// The code for the credit comment.
        /// </value>
        [Description("The code associated with the credit comment.")]
        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        /// <summary>
        /// Gets or sets the source type of the credit comment.
        /// </summary>
        /// <value>
        /// The source type of the credit comment.
        /// </value>
        [Description("The source type of the credit comment.")]
        [JsonProperty("@_SourceType")]
        public string? SourceType { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit comment.
        /// </summary>
        /// <value>
        /// The type of the credit comment.
        /// </value>
        [Description("The type of the credit comment.")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the description for other types not covered by standard types.
        /// </summary>
        /// <value>
        /// The description for other types.
        /// </value>
        [Description("The description for other types not covered by standard types.")]
        [JsonProperty("@_TypeOtherDescription")]
        public string? TypeOtherDescription { get; set; }
    }
}
