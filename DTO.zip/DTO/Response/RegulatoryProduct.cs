﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a regulatory product, including borrower, file, repository, provider, result, and disclaimer information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RegulatoryProduct
    {
        /// <summary>
        /// Gets or sets the identifier for the borrower associated with this regulatory product.
        /// </summary>
        /// <value>
        /// The borrower ID.
        /// </value>
        [Description("The identifier for the borrower associated with this regulatory product.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the credit file associated with this regulatory product.
        /// </summary>
        /// <value>
        /// The credit file ID.
        /// </value>
        [Description("The identifier for the credit file associated with this regulatory product.")]
        [JsonProperty("@CreditFileID")]
        public string? CreditFileID { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit repository source.
        /// </summary>
        /// <value>
        /// The credit repository source type.
        /// </value>
        [Description("The type of the credit repository source.")]
        [JsonProperty("@CreditRepositorySourceType")]
        public string? CreditRepositorySourceType { get; set; }

        /// <summary>
        /// Gets or sets the source type for the regulatory product.
        /// </summary>
        /// <value>
        /// The source type.
        /// </value>
        [Description("The source type for the regulatory product.")]
        [JsonProperty("@_SourceType")]
        public string? SourceType { get; set; }

        /// <summary>
        /// Gets or sets the provider description for the regulatory product.
        /// </summary>
        /// <value>
        /// The provider description.
        /// </value>
        [Description("The provider description for the regulatory product.")]
        [JsonProperty("@_ProviderDescription")]
        public string? ProviderDescription { get; set; }

        /// <summary>
        /// Gets or sets the result text for the regulatory product.
        /// </summary>
        /// <value>
        /// The result text.
        /// </value>
        [Description("The result text for the regulatory product.")]
        [JsonProperty("@_ResultText")]
        public string? ResultText { get; set; }

        /// <summary>
        /// Gets or sets the result status type for the regulatory product.
        /// </summary>
        /// <value>
        /// The result status type.
        /// </value>
        [Description("The result status type for the regulatory product.")]
        [JsonProperty("@_ResultStatusType")]
        public string? ResultStatusType { get; set; }

        /// <summary>
        /// Gets or sets the description for other credit repository source types.
        /// </summary>
        /// <value>
        /// The description for other credit repository source types.
        /// </value>
        [Description("The description for other credit repository source types.")]
        [JsonProperty("@CreditRepositorySourceTypeOtherDescription")]
        public string? CreditRepositorySourceTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the description for other result status types.
        /// </summary>
        /// <value>
        /// The description for other result status types.
        /// </value>
        [Description("The description for other result status types.")]
        [JsonProperty("@_ResultStatusTypeOtherDescription")]
        public string? ResultStatusTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the description for other source types.
        /// </summary>
        /// <value>
        /// The description for other source types.
        /// </value>
        [Description("The description for other source types.")]
        [JsonProperty("@_SourceTypeOtherDescription")]
        public string? SourceTypeOtherDescription { get; set; }

        /// <summary>
        /// Gets or sets the disclaimer text for the regulatory product.
        /// </summary>
        /// <value>
        /// The disclaimer text.
        /// </value>
        [Description("The disclaimer text for the regulatory product.")]
        [JsonProperty("@_DisclaimerText")]
        public string? DisclaimerText { get; set; }
    }
}
