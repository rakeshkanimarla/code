﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit summary, including borrower information, summary name, and associated data sets.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditSummary
    {
        /// <summary>
        /// Gets or sets the identifier for the borrower associated with this credit summary.
        /// </summary>
        /// <value>
        /// The borrower ID.
        /// </value>
        [Description("The identifier for the borrower associated with this credit summary.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the name of the credit summary.
        /// </summary>
        /// <value>
        /// The name of the credit summary.
        /// </value>
        [Description("The name of the credit summary.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the list of data sets associated with the credit summary.
        /// </summary>
        /// <value>
        /// The list of data sets.
        /// </value>
        [Description("The list of data sets associated with the credit summary.")]
        [JsonProperty("_DATA_SET")]
        public List<DataSet>? DataSet { get; set; }
    }
}