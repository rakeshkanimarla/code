﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    public class HighestAdverseRating
    {
        [JsonProperty("@_Amount")]
        public string? Amount { get; set; }

        [JsonProperty("@_Code")]
        public string? Code { get; set; }

        [JsonProperty("@_Date")]
        public string? Date { get; set; }

        [JsonProperty("@_Type")]
        public string? Type { get; set; }
    }
}
