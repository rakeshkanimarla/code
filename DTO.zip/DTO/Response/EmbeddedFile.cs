﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents an embedded file, including metadata such as ID, type, version, encoding, and document content.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class EmbeddedFile
    {
        /// <summary>
        /// Gets or sets the unique identifier for the embedded file.
        /// </summary>
        /// <value>
        /// The embedded file ID.
        /// </value>
        [Description("The unique identifier for the embedded file.")]
        [JsonProperty("@_ID")]
        public string? ID { get; set; }

        /// <summary>
        /// Gets or sets the type of the embedded file.
        /// </summary>
        /// <value>
        /// The embedded file type.
        /// </value>
        [Description("The type of the embedded file.")]
        [JsonProperty("@_Type")]
        public string? Type { get; set; }

        /// <summary>
        /// Gets or sets the version of the embedded file.
        /// </summary>
        /// <value>
        /// The embedded file version.
        /// </value>
        [Description("The version of the embedded file.")]
        [JsonProperty("@_Version")]
        public string? Version { get; set; }

        /// <summary>
        /// Gets or sets the name of the embedded file.
        /// </summary>
        /// <value>
        /// The embedded file name.
        /// </value>
        [Description("The name of the embedded file.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the encoding type of the embedded file.
        /// </summary>
        /// <value>
        /// The encoding type.
        /// </value>
        [Description("The encoding type of the embedded file.")]
        [JsonProperty("@_EncodingType")]
        public string? EncodingType { get; set; }

        /// <summary>
        /// Gets or sets the description of the embedded file.
        /// </summary>
        /// <value>
        /// The embedded file description.
        /// </value>
        [Description("The description of the embedded file.")]
        [JsonProperty("@_Description")]
        public string? Description { get; set; }

        /// <summary>
        /// Gets or sets the MIME type of the embedded file.
        /// </summary>
        /// <value>
        /// The MIME type.
        /// </value>
        [Description("The MIME type of the embedded file.")]
        [JsonProperty("@MIMEType")]
        public string? MIMEType { get; set; }

        /// <summary>
        /// Gets or sets the file extension of the embedded file.
        /// </summary>
        /// <value>
        /// The file extension.
        /// </value>
        [Description("The file extension of the embedded file.")]
        [JsonProperty("@_Extension")]
        public string? Extension { get; set; }

        /// <summary>
        /// Gets or sets the document content of the embedded file.
        /// </summary>
        /// <value>
        /// The document content.
        /// </value>
        [Description("The document content of the embedded file.")]
        [JsonProperty("DOCUMENT")]
        public string? Document { get; set; }
    }
}