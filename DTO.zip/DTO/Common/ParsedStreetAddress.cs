﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using Newtonsoft.Json;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a parsed street address, including house number, street name, and street suffix.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ParsedStreetAddress
    {
        /// <summary>
        /// Gets or sets the house number of the address.
        /// </summary>
        /// <value>
        /// The house number.
        /// </value>
        [Description("The house number of the address.")]
        [JsonProperty("@_HouseNumber")]
        public string? HouseNumber { get; set; }

        /// <summary>
        /// Gets or sets the street name of the address.
        /// </summary>
        /// <value>
        /// The street name.
        /// </value>
        [Description("The street name of the address.")]
        [JsonProperty("@_StreetName")]
        public string? StreetName { get; set; }

        /// <summary>
        /// Gets or sets the street suffix of the address.
        /// </summary>
        /// <value>
        /// The street suffix.
        /// </value>
        [Description("The street suffix of the address.")]
        [JsonProperty("@_StreetSuffix")]
        public string? StreetSuffix { get; set; }
    }
}