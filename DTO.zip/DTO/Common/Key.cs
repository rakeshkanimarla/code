﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a key-value pair used in the credit request model.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Key
    {
        /// <summary>
        /// Gets or sets the name of the key.
        /// </summary>
        /// <value>
        /// The name of the key.
        /// </value>
        [Description("The name of the key.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the value associated with the key.
        /// </summary>
        /// <value>
        /// The value associated with the key.
        /// </value>
        [Description("The value associated with the key.")]
        [JsonProperty("@_Value")]
        public string? Value { get; set; }
    }
}

