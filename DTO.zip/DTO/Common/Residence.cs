﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the residence details of a borrower.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Residence
    {
        /// <summary>
        /// Gets or sets the residency type of the borrower.
        /// </summary>
        /// <value>
        /// The residency type of the borrower.
        /// </value>
        [Description("The residency type of the borrower.")]
        [JsonProperty("@BorrowerResidencyType")]
        public string? BorrowerResidencyType { get; set; }

        /// <summary>
        /// Gets or sets the street address of the residence.
        /// </summary>
        /// <value>
        /// The street address of the residence.
        /// </value>
        [Description("The street address of the residence.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city of the residence.
        /// </summary>
        /// <value>
        /// The city of the residence.
        /// </value>
        [Description("The city of the residence.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state of the residence.
        /// </summary>
        /// <value>
        /// The state of the residence.
        /// </value>
        [Description("The state of the residence.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the residence.
        /// </summary>
        /// <value>
        /// The postal code of the residence.
        /// </value>
        [Description("The postal code of the residence.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the number of months the borrower has resided at the address.
        /// </summary>
        /// <value>
        /// The number of months at the residence.
        /// </value>
        [Description("The number of months the borrower has resided at the address.")]
        [JsonProperty("@BorrowerResidencyDurationMonths")]
        public string? BorrowerResidencyDurationMonths { get; set; }

        /// <summary>
        /// Gets or sets the number of years the borrower has resided at the address.
        /// </summary>
        /// <value>
        /// The number of years at the residence.
        /// </value>
        [Description("The number of years the borrower has resided at the address.")]
        [JsonProperty("@BorrowerResidencyDurationYears")]
        public string? BorrowerResidencyDurationYears { get; set; }

        /// <summary>
        /// Gets or sets the parsed street address details.
        /// </summary>
        /// <value>
        /// The parsed street address.
        /// </value>
        [Description("The parsed street address details.")]
        [JsonProperty("PARSED_STREET_ADDRESS")]
        public ParsedStreetAddress? ParsedStreetAddress { get; set; }
    }
}




