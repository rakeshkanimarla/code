﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the details of the requesting party in a credit request.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RequestingParty
    {
        /// <summary>
        /// Gets or sets the name of the requesting party.
        /// </summary>
        /// <value>
        /// The name of the requesting party.
        /// </value>
        [Description("The name of the requesting party.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the requesting party.
        /// </summary>
        /// <value>
        /// The street address of the requesting party.
        /// </value>
        [Description("The street address of the requesting party.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city of the requesting party.
        /// </summary>
        /// <value>
        /// The city of the requesting party.
        /// </value>
        [Description("The city of the requesting party.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state of the requesting party.
        /// </summary>
        /// <value>
        /// The state of the requesting party.
        /// </value>
        [Description("The state of the requesting party.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the requesting party.
        /// </summary>
        /// <value>
        /// The postal code of the requesting party.
        /// </value>
        [Description("The postal code of the requesting party.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the internal account identifier for the requesting party.
        /// </summary>
        /// <value>
        /// The internal account identifier.
        /// </value>
        [Description("The internal account identifier for the requesting party.")]
        [JsonProperty("@InternalAccountIdentifier")]
        public string? InternalAccountIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the lender case identifier for the requesting party.
        /// </summary>
        /// <value>
        /// The lender case identifier.
        /// </value>
        [Description("The lender case identifier for the requesting party.")]
        [JsonProperty("@LenderCaseIdentifier")]
        public string? LenderCaseIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the name of the person who requested the credit.
        /// </summary>
        /// <value>
        /// The name of the requester.
        /// </value>
        [Description("The name of the person who requested the credit.")]
        [JsonProperty("@_RequestedByName")]
        public string? RequestedByName { get; set; }
    }
}




