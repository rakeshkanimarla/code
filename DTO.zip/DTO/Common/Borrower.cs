﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using C1Plus.CBCCredit.Domain.Helper;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a borrower with personal details and associated information.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Borrower
    {
        /// <summary>
        /// Gets or sets the unique identifier for the borrower.
        /// </summary>
        /// <value>
        /// The unique identifier for the borrower.
        /// </value>
        [Description("Borrower ID")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the unique identifier for the borrower.
        /// </summary>
        /// <value>
        /// The unique identifier for the borrower.
        /// </value>
        [Description("Age At Application Years")]
        [JsonProperty("@_AgeAtApplicationYears")]
        public string? AgeAtApplicationYears { get; set; }

        /// <summary>
        /// Gets or sets the first name of the borrower.
        /// </summary>
        /// <value>
        /// The first name of the borrower.
        /// </value>
        [Description("First Name of the Borrower")]
        [JsonProperty("@_FirstName")]
        public string? FirstName { get; set; }

        /// <summary>
        /// Gets or sets the middle name of the borrower.
        /// </summary>
        /// <value>
        /// The middle name of the borrower.
        /// </value>
        [Description("Middle Name of the Borrower")]
        [JsonProperty("@_MiddleName")]
        public string? MiddleName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the borrower.
        /// </summary>
        /// <value>
        /// The last name of the borrower.
        /// </value>
        [Description("Last Name of the Borrower")]
        [JsonProperty("@_LastName")]
        public string? LastName { get; set; }

        /// <summary>
        /// Gets or sets the name suffix of the borrower (e.g., Jr., Sr.).
        /// </summary>
        /// <value>
        /// The name suffix of the borrower.
        /// </value>
        [Description("Name Suffix of the Borrower (e.g., Jr., Sr.)")]
        [JsonProperty("@_NameSuffix")]
        public string? NameSuffix { get; set; }

        /// <summary>
        /// Gets or sets the home telephone number of the borrower.
        /// </summary>
        /// <value>
        /// The home telephone number of the borrower.
        /// </value>
        [Description("Home Telephone Number of the Borrower")]
        [JsonProperty("@_HomeTelephoneNumber")]
        public string? HomeTelephoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the Social Security Number (SSN) of the borrower.
        /// </summary>
        /// <value>
        /// The Social Security Number (SSN) of the borrower.
        /// </value>
        [Description("Social Security Number (SSN) of the Borrower")]
        [JsonProperty("@_SSN")]
        public string? SSN { get; set; }

        /// <summary>
        /// Gets or sets the birth date of the borrower.
        /// </summary>
        /// <value>
        /// The birth date of the borrower.
        /// </value>
        [Description("Birth Date of the Borrower")]
        [JsonProperty("@_BirthDate")]
        public string? BirthDate { get; set; }

        /// <summary>
        /// Gets or sets the unparsed name of the borrower.
        /// </summary>
        /// <value>
        /// The unparsed name of the borrower.
        /// </value>
        [Description("Unparsed Name of the Borrower")]
        [JsonProperty("@_UnparsedName")]
        public string? UnparsedName { get; set; }


        /// <summary>
        /// Gets or sets the print position type of the borrower.
        /// </summary>
        /// <value>
        /// The print position type of the borrower.
        /// </value>
        [Description("Print Position Type of the Borrower")]
        [JsonProperty("@_PrintPositionType")]
        public string? PrintPositionType { get; set; }

        /// <summary>
        /// Gets or sets the residence information of the borrower.
        /// </summary>
        /// <value>
        /// The residence information of the borrower.
        /// </value>
        [Description("Residence Information of the Borrower")]
        [JsonProperty("_RESIDENCE")]
        [JsonConverter(typeof(SingleOrArrayConverter<Residence>))]
        public List<Residence>? Residence { get; set; }

        /// <summary>
        /// Gets or sets the mailing address of the borrower.
        /// </summary>
        /// <value>
        /// The mailing address of the borrower.
        /// </value>
        [Description("Mailing Address of the Borrower")]
        [JsonProperty("_MAIL_TO")]
        public MailTo? MailTo { get; set; }

        /// <summary>
        /// Gets or sets the employer information of the borrower.
        /// </summary>
        /// <value>
        /// The employer information of the borrower.
        /// </value>
        [Description("Employer Information of the Borrower")]
        [JsonProperty("EMPLOYER")]
        [JsonConverter(typeof(SingleOrArrayConverter<Employer>))]
        public List<Employer>? Employer { get; set; }
    }
}
