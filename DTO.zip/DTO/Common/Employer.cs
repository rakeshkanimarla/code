﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents an employer, including name, address, employment details, and related metadata.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Employer
    {
        /// <summary>
        /// Gets or sets the name of the employer.
        /// </summary>
        /// <value>
        /// The employer's name.
        /// </value>
        [Description("The name of the employer.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the employer.
        /// </summary>
        /// <value>
        /// The street address.
        /// </value>
        [Description("The street address of the employer.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city where the employer is located.
        /// </summary>
        /// <value>
        /// The city.
        /// </value>
        [Description("The city where the employer is located.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state where the employer is located.
        /// </summary>
        /// <value>
        /// The state.
        /// </value>
        [Description("The state where the employer is located.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the telephone number of the employer.
        /// </summary>
        /// <value>
        /// The telephone number.
        /// </value>
        [Description("The telephone number of the employer.")]
        [JsonProperty("@_TelephoneNumber")]
        public string? TelephoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the employer.
        /// </summary>
        /// <value>
        /// The postal code.
        /// </value>
        [Description("The postal code of the employer.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the start date of current employment.
        /// </summary>
        /// <value>
        /// The current employment start date.
        /// </value>
        [Description("The start date of current employment.")]
        [JsonProperty("@CurrentEmploymentStartDate")]
        public DateTime? CurrentEmploymentStartDate { get; set; }

        /// <summary>
        /// Gets or sets the indicator if the borrower is self-employed.
        /// </summary>
        /// <value>
        /// The self-employed indicator.
        /// </value>
        [Description("The indicator if the borrower is self-employed.")]
        [JsonProperty("@EmploymentBorrowerSelfEmployedIndicator")]
        public string? EmploymentBorrowerSelfEmployedIndicator { get; set; }

        /// <summary>
        /// Gets or sets the number of months on the current job.
        /// </summary>
        /// <value>
        /// The number of months on the current job.
        /// </value>
        [Description("The number of months on the current job.")]
        [JsonProperty("@CurrentEmploymentMonthsOnJob")]
        public string? CurrentEmploymentMonthsOnJob { get; set; }

        /// <summary>
        /// Gets or sets the number of years in the current line of work.
        /// </summary>
        /// <value>
        /// The number of years in the current line of work.
        /// </value>
        [Description("The number of years in the current line of work.")]
        [JsonProperty("@CurrentEmploymentTimeInLineOfWorkYears")]
        public string? CurrentEmploymentTimeInLineOfWorkYears { get; set; }

        /// <summary>
        /// Gets or sets the number of years on the current job.
        /// </summary>
        /// <value>
        /// The number of years on the current job.
        /// </value>
        [Description("The number of years on the current job.")]
        [JsonProperty("@CurrentEmploymentYearsOnJob")]
        public string? CurrentEmploymentYearsOnJob { get; set; }

        /// <summary>
        /// Gets or sets the indicator if this is the current employment.
        /// </summary>
        /// <value>
        /// The current employment indicator.
        /// </value>
        [Description("The indicator if this is the current employment.")]
        [JsonProperty("@EmploymentCurrentIndicator")]
        public string? EmploymentCurrentIndicator { get; set; }

        /// <summary>
        /// Gets or sets the position description for the employment.
        /// </summary>
        /// <value>
        /// The employment position description.
        /// </value>
        [Description("The position description for the employment.")]
        [JsonProperty("@EmploymentPositionDescription")]
        public string? EmploymentPositionDescription { get; set; }

        /// <summary>
        /// Gets or sets the date the employment was reported.
        /// </summary>
        /// <value>
        /// The employment reported date.
        /// </value>
        [Description("The date the employment was reported.")]
        [JsonProperty("@EmploymentReportedDate")]
        public string? EmploymentReportedDate { get; set; }

        /// <summary>
        /// Gets or sets the monthly income amount from employment.
        /// </summary>
        /// <value>
        /// The monthly income amount.
        /// </value>
        [Description("The monthly income amount from employment.")]
        [JsonProperty("@IncomeEmploymentMonthlyAmount")]
        public string? IncomeEmploymentMonthlyAmount { get; set; }

        /// <summary>
        /// Gets or sets the end date of previous employment.
        /// </summary>
        /// <value>
        /// The previous employment end date.
        /// </value>
        [Description("The end date of previous employment.")]
        [JsonProperty("@PreviousEmploymentEndDate")]
        public string? PreviousEmploymentEndDate { get; set; }

        /// <summary>
        /// Gets or sets the start date of previous employment.
        /// </summary>
        /// <value>
        /// The previous employment start date.
        /// </value>
        [Description("The start date of previous employment.")]
        [JsonProperty("@PreviousEmploymentStartDate")]
        public string? PreviousEmploymentStartDate { get; set; }

        /// <summary>
        /// Gets or sets the indicator if this is the primary employment.
        /// </summary>
        /// <value>
        /// The primary employment indicator.
        /// </value>
        [Description("The indicator if this is the primary employment.")]
        [JsonProperty("@EmploymentPrimaryIndicator")]
        public string? EmploymentPrimaryIndicator { get; set; }
    }
}