﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Class: DeterminationRequestModel
    /// Note: This class is created based on CBCCredit Response.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CBCCreditDeterminationResponse
    {
        /// <summary>
        /// Gets or sets the CBCCredit response model.
        /// </summary>
        /// <value>
        /// The CBCCredit response model.
        /// </value>
        [Description("The CBCCredit Response Model")]
        public CBCCreditResponseModel? CBCCreditResponseModel { get; set; }
    }
}
