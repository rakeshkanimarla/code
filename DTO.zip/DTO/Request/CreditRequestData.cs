﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the data associated with a credit request, including borrower details, credit report information, and repository indicators.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditRequestData
    {
        /// <summary>
        /// Gets or sets the unique identifier for the borrower.
        /// </summary>
        /// <value>
        /// The unique identifier for the borrower.
        /// </value>
        [Description("Unique identifier for the borrower.")]
        [JsonProperty("@BorrowerID")]
        public string? BorrowerID { get; set; }

        /// <summary>
        /// Gets or sets the Credit Request Date Time.
        /// </summary>
        /// <value>
        /// The Credit Request Date Time.
        /// </value>
        [Description("Credit Request Date Time")]
        [JsonProperty("@CreditRequestDateTime")]
        public string? CreditRequestDateTime { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the credit report.
        /// </summary>
        /// <value>
        /// The identifier for the credit report.
        /// </value>
        [Description("Identifier for the credit report.")]
        [JsonProperty("@CreditReportIdentifier")]
        public string? CreditReportIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the action type for the credit report request.
        /// </summary>
        /// <value>
        /// The action type for the credit report request.
        /// </value>
        [Description("Action type for the credit report request.")]
        [JsonProperty("@CreditReportRequestActionType")]
        public string? CreditReportRequestActionType { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit report.
        /// </summary>
        /// <value>
        /// The type of the credit report.
        /// </value>
        [Description("Type of the credit report.")]
        [JsonProperty("@reditReportType")]
        public string? CreditReportType { get; set; }

        /// <summary>
        /// Gets or sets the type of the credit request.
        /// </summary>
        /// <value>
        /// The type of the credit request.
        /// </value>
        [Description("Type of the credit request.")]
        [JsonProperty("@CreditRequestType")]
        public string? CreditRequestType { get; set; }

        /// <summary>
        /// Gets or sets the credit repository indicators, which specify the inclusion of Equifax, Experian, and TransUnion.
        /// </summary>
        /// <value>
        /// The credit repository indicators.
        /// </value>
        [Description("Credit repository indicators specifying the inclusion of Equifax, Experian, and TransUnion.")]
        [JsonProperty("CREDIT_REPOSITORY_INCLUDED")]
        public required CreditRepositoryIncluded CreditRepositoryIncluded { get; set; }
    }
}
