﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the credit repository indicators for a borrower, including Equifax, Experian, and TransUnion.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditRepositoryIncluded
    {
        /// <summary>
        /// Gets or sets the Equifax indicator, which specifies whether Equifax is included in the credit report.
        /// </summary>
        /// <value>
        /// The Equifax indicator.
        /// </value>
        [Description("Specifies whether Equifax is included in the credit report.")]
        [JsonProperty("@_EquifaxIndicator")]
        public required string EquifaxIndicator { get; set; }

        /// <summary>
        /// Gets or sets the Experian indicator, which specifies whether Experian is included in the credit report.
        /// </summary>
        /// <value>
        /// The Experian indicator.
        /// </value>
        [Description("Specifies whether Experian is included in the credit report.")]
        [JsonProperty("@_ExperianIndicator")]
        public required string ExperianIndicator { get; set; }

        /// <summary>
        /// Gets or sets the TransUnion indicator, which specifies whether TransUnion is included in the credit report.
        /// </summary>
        /// <value>
        /// The TransUnion indicator.
        /// </value>
        [Description("Specifies whether TransUnion is included in the credit report.")]
        [JsonProperty("@_TransUnionIndicator")]
        public required string TransUnionIndicator { get; set; }
    }
}
