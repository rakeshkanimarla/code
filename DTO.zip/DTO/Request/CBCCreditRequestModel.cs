﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the model for a CBC Credit Request, containing details about the request and involved parties.
    /// </summary>
    [ExcludeFromCodeCoverage]

    public class CBCCreditRequestModel
    {
        /// <summary>
        /// Gets or sets the details of the requesting group.
        /// </summary>
        /// <value>
        /// The details of the requesting group.
        /// </value>
        [Description("The details of the requesting group.")]
        [JsonProperty("REQUEST_GROUP")]
        public required RequestGroup RequestGroup { get; set; }
       
    }
}
