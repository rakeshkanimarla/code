﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a credit request with associated details, including lender information, requesting party, and loan application details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreditRequest
    {
        /// <summary>
        /// Gets or sets the lender case identifier, which uniquely identifies the lender's case.
        /// </summary>
        /// <value>
        /// The lender case identifier.
        /// </value>
        [Description("Unique identifier for the lender's case.")]
        [JsonProperty("@LenderCaseIdentifier")]
        public string? LenderCaseIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the MISMO version ID, which specifies the version of the MISMO standard used.
        /// </summary>
        /// <value>
        /// The MISMO version ID.
        /// </value>
        [Description("Version ID of the MISMO standard used.")]
        [JsonProperty("@MISMOVersionID")]
        public string? MISMOVersionID { get; set; }

        /// <summary>
        /// Gets or sets the name of the requesting party who requested the credit report.
        /// </summary>
        /// <value>
        /// The name of the requesting party.
        /// </value>
        [Description("Name of the requesting party who requested the credit report.")]
        [JsonProperty("@RequestingPartyRequestedByName")]
        public string? RequestingPartyRequestedByName { get; set; }

        /// <summary>
        /// Gets or sets the credit request data, which includes details about the credit report and repositories.
        /// </summary>
        /// <value>
        /// The credit request data.
        /// </value>
        [Description("Details about the credit report and repositories.")]
        [JsonProperty("CREDIT_REQUEST_DATA")]
        public required CreditRequestData CreditRequestData { get; set; }

        /// <summary>
        /// Gets or sets the loan application details, including borrower information.
        /// </summary>
        /// <value>
        /// The loan application details.
        /// </value>
        [Description("Details of the loan application, including borrower information.")]
        [JsonProperty("LOAN_APPLICATION")]
        public required LoanApplication LoanApplication { get; set; }
    }
}
