﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the data associated with a request, including credit request details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RequestData
    {
        /// <summary>
        /// Gets or sets the credit request details.
        /// </summary>
        /// <value>
        /// The credit request details.
        /// </value>
        [Description("Details of the credit request.")]
        [JsonProperty("CREDIT_REQUEST")]
        public required CreditRequest CreditRequest { get; set; }
    }
}



