﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a group of related credit request information, including MISMO identifiers, versioning, and party details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class RequestGroup
    {
        /// <summary>
        /// Gets or sets the MISMO identifier for the credit request.
        /// </summary>
        /// <value>
        /// The MISMO identifier.
        /// </value>
        [Description("MISMO Identifier for the Credit Request")]
        public string? MISMO { get; set; }

        /// <summary>
        /// Gets or sets the version ID of the MISMO standard.
        /// </summary>
        /// <value>
        /// The MISMO version ID.
        /// </value>
        [Description("Version ID of the MISMO Standard")]
        [JsonProperty("@MISMOVersionID")]
        public required string MISMOVersionID { get; set; }

        /// <summary>
        /// Gets or sets the details of the requesting party.
        /// </summary>
        /// <value>
        /// The requesting party details.
        /// </value>
        [Description("Details of the Requesting Party")]
        [JsonProperty("REQUESTING_PARTY")]
        public RequestingParty? RequestingParty { get; set; }

        /// <summary>
        /// Gets or sets the details of the receiving party.
        /// </summary>
        /// <value>
        /// The receiving party details.
        /// </value>
        [Description("Details of the Receiving Party")]
        [JsonProperty("RECEIVING_PARTY")]
        public ReceivingParty? ReceivingParty { get; set; }

        /// <summary>
        /// Gets or sets the details of the submitting party.
        /// </summary>
        /// <value>
        /// The submitting party details.
        /// </value>
        [Description("Details of the Submitting Party")]
        [JsonProperty("SUBMITTING_PARTY")]
        public SubmittingParty? SubmittingParty { get; set; }

        /// <summary>
        /// Gets or sets the details of the credit request.
        /// </summary>
        /// <value>
        /// The credit request details.
        /// </value>
        [Description("Details of the Credit Request")]
        [JsonProperty("REQUEST")]
        public required Request Request { get; set; }
    }
}
