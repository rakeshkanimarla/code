﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents the details of the submitting party in a credit request.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class SubmittingParty
    {
        /// <summary>
        /// Gets or sets the name of the submitting party.
        /// </summary>
        /// <value>
        /// The name of the submitting party.
        /// </value>
        [Description("The name of the submitting party.")]
        [JsonProperty("@_Name")]
        public string? Name { get; set; }

        /// <summary>
        /// Gets or sets the street address of the submitting party.
        /// </summary>
        /// <value>
        /// The street address of the submitting party.
        /// </value>
        [Description("The street address of the submitting party.")]
        [JsonProperty("@_StreetAddress")]
        public string? StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets the city of the submitting party.
        /// </summary>
        /// <value>
        /// The city of the submitting party.
        /// </value>
        [Description("The city of the submitting party.")]
        [JsonProperty("@_City")]
        public string? City { get; set; }

        /// <summary>
        /// Gets or sets the state of the submitting party.
        /// </summary>
        /// <value>
        /// The state of the submitting party.
        /// </value>
        [Description("The state of the submitting party.")]
        [JsonProperty("@_State")]
        public string? State { get; set; }

        /// <summary>
        /// Gets or sets the postal code of the submitting party.
        /// </summary>
        /// <value>
        /// The postal code of the submitting party.
        /// </value>
        [Description("The postal code of the submitting party.")]
        [JsonProperty("@_PostalCode")]
        public string? PostalCode { get; set; }
    }
}





