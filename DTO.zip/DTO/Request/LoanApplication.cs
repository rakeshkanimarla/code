﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a loan application containing borrower details.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class LoanApplication
    {
        /// <summary>
        /// Gets or sets the borrower details associated with the loan application.
        /// </summary>
        /// <value>
        /// A list of borrower details.
        /// </value>
        [Description("List of borrower details associated with the loan application.")]
        [JsonProperty("BORROWER")]
        public required List<Borrower> Borrower { get; set; }
    }
}

