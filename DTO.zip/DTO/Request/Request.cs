﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using Newtonsoft.Json;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Represents a request containing details such as request date, account identifier, keys, and request data.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Request
    {
        /// <summary>
        /// Gets or sets the date and time of the request.
        /// </summary>
        /// <value>
        /// The date and time of the request.
        /// </value>
        [Description("The date and time of the request.")]
        [JsonProperty("@RequestDatetime")]
        public string? RequestDateTime { get; set; } = DateTime.Now.ToString(CultureInfo.InvariantCulture);

        /// <summary>
        /// Gets or sets the internal account identifier.
        /// </summary>
        /// <value>
        /// The internal account identifier.
        /// </value>
        [Description("The internal account identifier.")]
        [JsonProperty("@InternalAccountIdentifier")]
        public string? InternalAccountIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the list of key-value pairs associated with the request.
        /// </summary>
        /// <value>
        /// The list of key-value pairs.
        /// </value>
        [Description("The list of key-value pairs associated with the request.")]
        [JsonProperty("KEY")]
        public List<Key>? Key { get; set; }

        /// <summary>
        /// Gets or sets the request data containing additional details.
        /// </summary>
        /// <value>
        /// The request data.
        /// </value>
        [Description("The request data containing additional details.")]
        [JsonProperty("REQUEST_DATA")]
        public required RequestData RequestData { get; set; }
    }
}



