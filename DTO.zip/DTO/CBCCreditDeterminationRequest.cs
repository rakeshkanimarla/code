﻿// Copyright © 2024 Wolters Kluwer Financial Services, Inc. All rights reserved.

using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;

namespace C1Plus.CBCCredit.Domain.DTO
{
    /// <summary>
    /// Class: DeterminationRequestModel
    /// Note: This class is created based on CBCCredit Request.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CBCCreditDeterminationRequest
    {
        /// <summary>
        /// Gets or sets the loan file id.
        /// </summary>
        /// <value>
        /// The loan file id.
        /// </value>
        [Description("Loan File ID")]
        public string? LoanFileID { get; set; }

        /// <summary>
        /// Gets or sets the loan number.
        /// </summary>
        /// <value>
        /// The loan number.
        /// </value>
        [Description("Loan Number")]
        public string? LoanNumber { get; set; }

        /// <summary>
        /// Gets or sets the client id.
        /// </summary>
        /// <value>
        /// The client id.
        /// </value>
        [Description("Client ID")]
        public string? ClientID { get; set; }

        /// <summary>
        /// Gets or sets the lob.
        /// </summary>
        /// <value>
        /// The lob.
        /// </value>
        [Description("The LOB")]
        public string? LOB { get; set; }

        /// <summary>
        /// Gets or sets the CBCCredit request model.
        /// </summary>
        /// <value>
        /// The CBCCredit request model.
        /// </value>
        [Description("The CBCCredit Request Model")]
        public CBCCreditRequestModel? CBCCreditRequestModel { get; set; }
    }
}
